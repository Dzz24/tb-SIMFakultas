import FormLogin from "../components/FormLogin";
import Navbar from "../components/Navbar"
import axios from 'axios';

function Login (){
    return (
        <>
        <div>
            <FormLogin/>
        </div>
        </>
    )
}
export default Login;